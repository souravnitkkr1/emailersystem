

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DraftServletProcess
 */
@WebServlet("/DraftServletProcess")
public class DraftServletProcess extends HttpServlet {
	private static final long serialVersionUID = 1L;
      static int count=0; 
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DraftServletProcess() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		request.getRequestDispatcher("header.html").include(request, response);
		
		String subject=request.getParameter("subject");
		String message=request.getParameter("message");
		message=message.replaceAll("\n","<br/>");
		String email=(String)request.getSession(false).getAttribute("email");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/emailer_system", "root", "");
//here javadb is database name, root is username and password  
			Statement stmt = con.createStatement();
			count++;
			String st=count+",'"+email+"','"+subject+"','"+message+"'";
			System.out.println(st);
			int s=stmt.executeUpdate("insert into draft values("+st+")");
			if(s>0){
				request.setAttribute("msg","message saved as draft");
				request.getRequestDispatcher("DraftServlet").forward(request, response);
			}
			
			
			request.getRequestDispatcher("footer.html").include(request, response);
			out.close();
			System.out.println(s+" Records inserted"); 
			con.close();
		}
catch (Exception e) {
			System.out.println(e);
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
