import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		System.out.println("Hi");
		PrintWriter out=response.getWriter();
		request.getRequestDispatcher("header.html").include(request, response);		
		String email=request.getParameter("email");
		String password=request.getParameter("password");
		try {
			//loading the driver
			Class.forName("com.mysql.jdbc.Driver");
			//returns connection Object : getConnection(URL, username, password)
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/emailer_system", "root", "");
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from newuser");
			System.out.println(rs);
			int flag=0;
			while (rs.next())
			{
				System.out.println(rs.getString(2));
				System.out.println(rs.getString(3));
				//rs has three columns : int, varchar(), int: 1, 2, 3 represents column numbers
				if(rs.getString(2).equals(email) && rs.getString(3).equals(password))
				{
					flag=1;
					System.out.println("1");
					break;
				}
				//out.println(rs.getInt(1) + "  " + rs.getString(2) + "  " + rs.getInt(3)+"<br>");
				//con.close();
			}
			if(flag==1)
			{
				request.getSession().setAttribute("login", "true");
				request.getSession().setAttribute("email", email);
				response.sendRedirect("InboxServlet");
			}
			else{
				out.print("<p>Sorry, username or password error</p>");
				request.getRequestDispatcher("login.html").include(request, response);
			}
			
		} catch (Exception e) {
			System.out.println(e);
		}
		
		request.getRequestDispatcher("footer.html").include(request, response);
		out.close();
	}

}
